const InventorySystem = {
    inventory: [
        { id: 1, name: "Wireless Mouse", price: 25, stock: 10 },
        { id: 2, name: "Keyboard", price: 45, stock: 0 },
        { id: 3, name: "Monitor", price: 500, stock: 20 },
        { id: 4, name: "SSD", price: 100, stock: 5 },
        { id: 5, name: "Speakers", price: 120, stock: 12 }
    ],

    renderTable: function () {
        let tbody = document.getElementById("tableBody");
        tbody.innerHTML = "";

        this.inventory.forEach(item => {
            let stockText = item.stock === 0
                ? `<span class="out">Out of Stock</span>`
                : item.stock;

            tbody.innerHTML += `
                <tr>
                    <td>${item.id}</td>
                    <td>${item.name}</td>
                    <td>${stockText}</td>
                </tr>
            `;
        });
    },
    addProduct: function (name, price, stock) {
        let newProduct = {
            id: this.inventory.length + 1,
            name: name,
            price: parseFloat(price),
            stock: parseInt(stock)
        };

        this.inventory.push(newProduct);
        this.renderTable();
    },

    init: function () {
        document.getElementById("productForm").addEventListener("submit", (e) => {
            e.preventDefault();

            let name = document.getElementById("productName").value;
            let price = document.getElementById("price").value;
            let stock = document.getElementById("stock").value;

            this.addProduct(name, price, stock);

            e.target.reset();
        });

        this.renderTable();
    }
};

InventorySystem.init();