let inventory = [
    {id: 1, name: "Wireless Mouse", price: 25, stock: 10},
    {id: 2, name: "Keyboard", price: 45, stock: 0},
    {id: 3, name: "Monitor", price: 500, stock: 20},
    {id: 4, name: "SSD", price: 100, stock: 5},
    {id: 5, name: "Speakers", price: 120, stock: 12}
];

function renderTable(){
    let tbody = document.getElementById("tableBody");
    tbody.innerHTML = '';

    inventory.forEach(item =>{
        let stockText = item.stock === 0 
        ? `<span class="out">Out of Stock</span>`
        : item.stock;

        tbody.innerHTML += `
            <tr>
                <td>${item.id}</td>
                <td>${item.name}</td>
                <td>$${item.price}</td>
                <td>${stockText}</td>
            </tr>
        `;
    });
}

document.getElementById("productForm").addEventListener("submit", function(e){
    e.preventDefault();

    let name = document.getElementById("productName").value;
    let price = document.getElementById("price").value;
    let stock = document.getElementById("stock").value;

    let newProduct = {
        id: inventory.length + 1,
        name: name,
        price: Number(price),
        stock: Number(stock)
    };

    inventory.push(newProduct);
    renderTable();
    this.reset();
});

renderTable();