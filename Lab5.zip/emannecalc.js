// Calculator logic for emannecalc.html
// Attach this script to your HTML file

function formatAnswer(value, decimals = 8) {
  if (!isFinite(value)) return String(value);
  const nearest = Math.round(value);
  if (Math.abs(value - nearest) < Math.pow(10, -decimals)) return String(nearest);
  const sign = Math.sign(value) || 1;
  const factor = Math.pow(10, decimals);
  const truncated = Math.floor(Math.abs(value) * factor) / factor * sign;
  let s = String(truncated);
  if (s.indexOf('.') !== -1) s = s.replace(/\.?0+$/, '');
  return s;
}

// Calculator functionality
window.addEventListener('DOMContentLoaded', function() {
  const display = document.querySelector('.display');
  const buttons = document.querySelectorAll('.btn');
  let current = '';
  let operator = '';
  let operand = null;

  function updateDisplay(val) {
    display.value = val;
  }

  buttons.forEach(btn => {
    btn.addEventListener('click', function() {
      const value = btn.textContent;
      if (btn.classList.contains('clear')) {
        current = '';
        operator = '';
        operand = null;
        updateDisplay('');
      } else if (btn.classList.contains('equals')) {
        if (operator && operand !== null && current !== '') {
          let result;
          try {
            switch(operator) {
              case '+': result = operand + parseFloat(current); break;
              case '-': result = operand - parseFloat(current); break;
              case '×': result = operand * parseFloat(current); break;
              case '÷': result = operand / parseFloat(current); break;
              default: result = parseFloat(current);
            }
            updateDisplay(formatAnswer(result));
            current = String(result);
            operator = '';
            operand = null;
          } catch {
            updateDisplay('Error');
          }
        }
      } else if (btn.classList.contains('operator')) {
        if (current !== '') {
          operator = value;
          operand = parseFloat(current);
          current = '';
        }
      } else {
        current += value;
        updateDisplay(current);
      }
    });
  });
});
